The file is run with as indicated in the HW5.pdf file found in Piazza. 

Arguments: 
1) Name of the File. In this case, "hw5.py".
2) Name of the data set analyzed.
3) Number of clusters from 2 to 6. 
4) Name of the output file. 

For the matplotlib plots to be seen, uncomment all of the portions of code that are commented. I used it to visually prove that the algorithm was working but did not think it was necessary to have them open every time I ran the algoritm. 

In the output file there are a 5 different outcomes for each of the cluster possibilities. The division comes on the line right after Silhouette Coefficient. The first block is with k = 2, the second is with k = 3, and so on until 'k' reaches 6.