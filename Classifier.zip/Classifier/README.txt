My code is ran as a regular python script. Using the command 'python' and the name of the file, in this case 'hw4.py'. There are no extra arguments because its a static csv file. 

The graphs are generated using matplotlib and will appear on the user's screen after running the program. 